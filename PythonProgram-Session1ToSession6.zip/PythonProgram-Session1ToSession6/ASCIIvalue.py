# Python Program - Print ASCII Values
		
for i in range(1, 255):
    ch = chr(i);
    print(i, "=", ch);