# Python Program - Find Length of String

print("Enter 'x' for exit.")
string = input("Enter a string to find its length: ")
if string == 'x':
    exit();
else:
    print("